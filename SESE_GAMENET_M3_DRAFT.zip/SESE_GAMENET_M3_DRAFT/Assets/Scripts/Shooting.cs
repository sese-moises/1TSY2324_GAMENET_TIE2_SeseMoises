using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using TMPro;

public class Shooting : MonoBehaviourPunCallbacks
{
    public float GetHealth
    {
        get => health;
    }

    public Camera cam;
    public GameObject _hitEffectPrefab;

    [Header("HP Related Stuff")]
    public float startHealth = 100;
    private float health;
    public Image healthBar;
    private bool canShoot = true;

    private GameObject killAnnouncement;
    private GameObject winnerAnnouncement;

    void Start()
    {
        health = startHealth;
        healthBar.fillAmount = health / startHealth;
        winnerAnnouncement = GameObject.Find("WinnerAnnouncement");
        killAnnouncement = GameObject.Find("KillAnnouncement");
        //photonView.RPC("ClearAnnouncement", RpcTarget.AllBuffered);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && canShoot)
        {
            canShoot = false;
            Fire();
        }
    }

    public void Fire()
    {
        RaycastHit hit;
        Ray ray = cam.ViewportPointToRay(new Vector3(0.5f, 0.5f));

        if (Physics.Raycast(ray, out hit, 200))
        {
            Debug.Log(hit.collider.gameObject.name);

            //photonView.RPC("CreateHitEffects", RpcTarget.All, hit.point);

            if (hit.collider.gameObject.CompareTag("Player") && !hit.collider.gameObject.GetComponent<PhotonView>().IsMine
                && hit.collider.gameObject.GetComponent<Shooting>().GetHealth > 0)
            {
                int id = this.photonView.ViewID;
                hit.collider.gameObject.GetComponent<PhotonView>().RPC("TakeDamage", RpcTarget.AllBuffered, 25, id);
            }
        }
        Invoke("Shoot", 0.5f);
    }

    public void Shoot()
    {
        canShoot = true;
    }

    [PunRPC]
    public void TakeDamage(int damage, int viewID, PhotonMessageInfo info)
    {
        this.health -= damage;
        this.healthBar.fillAmount = health / startHealth;

        if (health <= 0)
        {
            Die();
            killAnnouncement.GetComponent<Text>().text = info.Sender.NickName + " killed " + info.photonView.Owner.NickName;

            //photonView.RPC("EndGame", RpcTarget.AllBuffered, info.Sender.NickName);
        }
    }

    [PunRPC]
    public void CreateHitEffects(Vector3 position)
    {
        GameObject hitEffectGameObject = Instantiate(_hitEffectPrefab, position, Quaternion.identity);
        Destroy(hitEffectGameObject, 0.2f);
    }

    public void Die()
    {
        if (photonView.IsMine)
        {
            this.gameObject.SetActive(false);
        }
    }

    [PunRPC]
    public void ClearAnnouncement()
    {
        killAnnouncement.GetComponent<TextMeshProUGUI>().text = "";
    }

    [PunRPC]
    public void RegainHealth()
    {
        health = 100;
        healthBar.fillAmount = health / startHealth;
    }

    [PunRPC]
    public void EndGame(string winner)
    {
        winnerAnnouncement.GetComponent<TextMeshProUGUI>().text = winner + " WINS!";

        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

        foreach (GameObject p in players)
        {
            p.transform.GetComponent<VehicleMovement>().enabled = false;
        }
    }
}
